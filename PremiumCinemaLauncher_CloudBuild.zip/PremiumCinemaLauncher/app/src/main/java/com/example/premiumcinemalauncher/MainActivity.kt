package com.example.premiumcinemalauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var clock: TextView
    private lateinit var weather: TextView
    private lateinit var appRow: LinearLayout
    private val mainHandler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var wallpaperUri: Uri? = null
    private val tick = object : Runnable {
        override fun run() {
            if (::clock.isInitialized) {
                clock.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
                findViewById<TextView>(R.id.dateText)?.text =
                    SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            }
            mainHandler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildUi()
        loadWeather()
        mainHandler.post(tick)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(28), dp(42), dp(26))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 17, 34), Color.rgb(24, 29, 60), Color.rgb(7, 10, 20))
            )
        }
        setContentView(root)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "◈  PREMIUM  CINEMA"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = 0.12f
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(44), 1f))

        clock = TextView(this).apply {
            text = "--:--"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.END
        }
        top.addView(clock)
        root.addView(top)

        val date = TextView(this).apply {
            id = R.id.dateText
            text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            textSize = 14f
            setTextColor(Color.rgb(190, 198, 220))
            gravity = Gravity.END
        }
        root.addView(date)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(26), dp(10), dp(20), dp(10))
        }
        val heroTitle = TextView(this).apply {
            text = "Your screen.\\nYour cinema."
            textSize = 38f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setShadowLayer(12f, 0f, 3f, Color.BLACK)
        }
        hero.addView(heroTitle)
        val subtitle = TextView(this).apply {
            text = "Everything you love, one click away."
            textSize = 16f
            setTextColor(Color.rgb(202, 208, 230))
            setPadding(0, dp(8), 0, dp(10))
        }
        hero.addView(subtitle)
        weather = TextView(this).apply {
            text = "Weather · loading…"
            textSize = 14f
            setTextColor(Color.rgb(221, 226, 245))
        }
        hero.addView(weather)
        root.addView(hero, LinearLayout.LayoutParams(-1, 0, 1.15f))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(actionButton("⌕  Search", "Search apps and the web") { openSearch() },
            LinearLayout.LayoutParams(0, dp(54), 1.1f))
        actions.addView(actionButton("▧  Wallpaper", "Choose a custom background") { chooseWallpaper() },
            LinearLayout.LayoutParams(0, dp(54), 1f))
        actions.addView(actionButton("↻  Refresh weather", "Update weather") { loadWeather() },
            LinearLayout.LayoutParams(0, dp(54), 1f))
        root.addView(actions)

        val label = TextView(this).apply {
            text = "YOUR APPS"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(175, 187, 220))
            setPadding(0, dp(22), 0, dp(10))
        }
        root.addView(label)
        appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(appRow, LinearLayout.LayoutParams(-1, dp(100)))
        populateApps()
        actions.getChildAt(0).requestFocus()
    }

    private fun populateApps() {
        appRow.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val results = try { pm.queryIntentActivities(intent, 0) } catch (_: Exception) { emptyList() }
        val seen = HashSet<String>()
        val own = packageName
        val apps = results.filter {
            val p = it.activityInfo?.packageName ?: ""
            p.isNotBlank() && p != own && seen.add(p)
        }.sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }.take(7)

        for (resolve in apps) {
            val info = resolve.activityInfo ?: continue
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = rounded(Color.argb(170, 255, 255, 255), dp(14))
                setPadding(dp(10), dp(8), dp(10), dp(8))
                contentDescription = info.loadLabel(pm).toString()
                setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(info.packageName)
                    if (launch != null) try { startActivity(launch) } catch (_: Exception) {}
                }
                setOnFocusChangeListener { v, focused ->
                    v.scaleX = if (focused) 1.06f else 1f
                    v.scaleY = if (focused) 1.06f else 1f
                    v.background = rounded(
                        if (focused) Color.rgb(110, 127, 255) else Color.argb(170, 255, 255, 255),
                        dp(14)
                    )
                }
            }
            val icon = TextView(this).apply {
                text = "▶"
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                try {
                    val drawable = resolve.loadIcon(pm)
                    drawable.setBounds(0, 0, dp(34), dp(34))
                    setCompoundDrawables(null, drawable, null, null)
                    text = ""
                } catch (_: Exception) {}
            }
            tile.addView(icon, LinearLayout.LayoutParams(-1, dp(43)))
            val name = TextView(this).apply {
                text = resolve.loadLabel(pm).toString()
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(0, dp(5), 0, 0)
            }
            tile.addView(name)
            val lp = LinearLayout.LayoutParams(0, dp(88), 1f)
            lp.marginEnd = dp(10)
            appRow.addView(tile, lp)
        }
        if (apps.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No TV apps detected yet. Install apps, then reopen this launcher."
                setTextColor(Color.WHITE)
                textSize = 14f
            }
            appRow.addView(empty)
        }
    }

    private fun actionButton(title: String, description: String, action: () -> Unit): Button =
        Button(this).apply {
            text = title
            contentDescription = description
            isFocusable = true
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = rounded(Color.argb(55, 255, 255, 255), dp(14))
            setOnFocusChangeListener { v, focused ->
                v.background = rounded(
                    if (focused) Color.rgb(92, 111, 245) else Color.argb(55, 255, 255, 255),
                    dp(14)
                )
            }
            setOnClickListener { action() }
        }

    private fun openSearch() {
        val edit = android.widget.EditText(this).apply {
            hint = "Search Google or enter a topic"
            setSingleLine(true)
            textSize = 18f
        }
        AlertDialog.Builder(this)
            .setTitle("Search")
            .setView(edit)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Search") { _, _ ->
                val q = edit.text.toString().trim()
                if (q.isNotEmpty()) {
                    val url = "https://www.google.com/search?q=" + Uri.encode(q)
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
                }
            }.show()
    }

    private fun chooseWallpaper() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try { startActivityForResult(pick, 1001) }
        catch (_: Exception) {
            AlertDialog.Builder(this).setMessage("This device does not provide a file picker. Copy a wallpaper to the TV and try again.")
                .setPositiveButton("OK", null).show()
        }
    }

    @Deprecated("Legacy callback used for broad Android TV compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            wallpaperUri = uri
            try {
                val stream = contentResolver.openInputStream(uri)
                val bitmap = stream?.use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) {
                    root.background = BitmapDrawable(resources, bitmap).apply {
                        alpha = 115
                        gravity = Gravity.FILL
                    }
                    // Overlay-friendly background; UI remains readable.
                }
            } catch (_: Exception) {
                AlertDialog.Builder(this).setMessage("Could not load that image. Try a JPG or PNG wallpaper.")
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun loadWeather() {
        weather.text = "Weather · checking Dhaka…"
        io.execute {
            var result = "Weather unavailable · check internet"
            var connection: HttpURLConnection? = null
            try {
                // Default location is Dhaka. Change latitude/longitude for your city.
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=23.8103&longitude=90.4125&current=temperature_2m,weather_code&timezone=Asia%2FDhaka")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000
                    readTimeout = 7000
                    requestMethod = "GET"
                }
                if (connection.responseCode in 200..299) {
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    val current = JSONObject(body).getJSONObject("current")
                    val temp = current.optDouble("temperature_2m", Double.NaN)
                    val code = current.optInt("weather_code", -1)
                    if (!temp.isNaN()) result = "Dhaka  ·  ${temp.toInt()}°C  ·  ${weatherLabel(code)}"
                }
            } catch (_: Exception) {
            } finally { connection?.disconnect() }
            mainHandler.post { if (::weather.isInitialized) weather.text = result }
        }
    }

    private fun weatherLabel(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Showers"
        95, 96, 99 -> "Thunderstorm"
        else -> "Current weather"
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        mainHandler.removeCallbacks(tick)
        io.shutdownNow()
        super.onDestroy()
    }
}
