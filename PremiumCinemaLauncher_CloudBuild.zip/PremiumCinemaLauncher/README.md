# Premium Cinema Launcher (Android TV / Google TV)

A starter Android Studio project for a cinematic home screen with:
- TV app shortcuts discovered from apps that expose a Leanback launcher activity
- Custom wallpaper picker (image files supported by the TV's document picker)
- Clock and date
- Weather from Open-Meteo (default coordinates: Dhaka, Bangladesh)
- Search dialog that opens Google Search in an available browser
- D-pad / remote focus styling
- HOME intent filter so Android may offer it as a launcher

## Important limitations
- This is a **starter project**, not a tested, precompiled APK. Build it with Android Studio first.
- Google TV may not let third-party launchers fully replace the stock home screen. The HOME intent filter may show a chooser, be ignored, or be restricted by the device/Google TV version.
- Some apps do not expose a TV/Leanback launch activity and therefore will not appear in the shortcut row.
- Search opens a web search in an installed browser; it does not implement Google Assistant voice search.
- Weather requires internet. It uses Open-Meteo's public forecast endpoint without an API key and defaults to Dhaka. Edit the URL in `MainActivity.kt` to use another location.
- Wallpaper changes are currently applied in the running session; this starter does not persist the selected image across a reboot.
- App visibility/package queries vary by Android version and device vendor. Extend the manifest queries if needed for specific apps.

## Build an APK
1. Install the latest stable **Android Studio** on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `PremiumCinemaLauncher` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible JDK (Android Studio's bundled JDK is recommended).
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When successful, use **Locate** in the notification. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`

## Install on Google TV
1. Copy `app-debug.apk` to a USB drive or transfer it with a trusted local file-transfer app.
2. On the TV, enable installation from that file manager/source if Android asks. Only install APKs you trust.
3. Open the APK and install.
4. Launch **Premium Cinema** from the Apps list.
5. If the TV offers a Home-app selection dialog, choose Premium Cinema. If it does not, the device may restrict third-party home launchers; you can still open it from Apps.

## Customize
- App label: `app/src/main/AndroidManifest.xml`
- Colors and typography: `MainActivity.kt`
- Default weather location: URL in `loadWeather()`
- Package name: `applicationId` in `app/build.gradle.kts` and `namespace` / Kotlin package path. Keep these consistent when changing it.


## Build from an iPhone using GitHub Actions (no computer required)

This repository includes `.github/workflows/build-apk.yml` so GitHub's cloud runner can build the debug APK.

1. In Safari, sign in to GitHub and create a **new repository** (a private repository is fine).
2. Upload the contents of this project folder to the repository. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile website does not let you upload a folder, use the repository's **Add file** flow and upload files in smaller batches; hidden `.github` files/folders may need to be created using GitHub's web editor.
3. In the repository, open **Actions**. If prompted, enable workflows.
4. Select **Build Premium Cinema Launcher APK**. Tap **Run workflow** (or push/commit to the `main` branch to trigger it).
5. Wait for the run to finish with a green check.
6. Open the completed workflow run, scroll to **Artifacts**, and download `premium-cinema-launcher-debug-apk`.
7. On iPhone, the artifact normally downloads as a ZIP. Save it to the Files app and extract it to find `app-debug.apk`.
8. Transfer the APK to the Haier Google TV using a trusted file-transfer method, then install it on the TV if its security settings permit.

### Notes
- GitHub Actions builds the APK in the cloud; the iPhone itself is not compiling Android code.
- A debug APK is suitable for testing, not a signed release for public distribution.
- GitHub's mobile website interface can change. If creating the `.github/workflows` file from Safari is awkward, upload the project using GitHub's web interface on a trusted computer once, or use a Git client/workflow that preserves hidden files.
- The app may install and run without being allowed to replace the Google TV's stock Home screen. That depends on the TV firmware.
